# Load required packages
library(rvest)
library(dplyr)

# Define the URLs for shooting tables
urls <- list(
  "2020-2021" = "https://fbref.com/en/squads/b8fd03ef/2020-2021/matchlogs/all_comps/shooting/Manchester-City-Match-Logs-All-Competitions",
  "2021-2022" = "https://fbref.com/en/squads/b8fd03ef/2021-2022/matchlogs/all_comps/shooting/Manchester-City-Match-Logs-All-Competitions",
  "2022-2023" = "https://fbref.com/en/squads/b8fd03ef/2022-2023/matchlogs/all_comps/shooting/Manchester-City-Match-Logs-All-Competitions",
  "2023-2024" = "https://fbref.com/en/squads/b8fd03ef/2023-2024/matchlogs/all_comps/shooting/Manchester-City-Match-Logs-All-Competitions"
)

# Function to scrape and save the table
scrape_and_save <- function(url, season) {
  # Read the webpage content
  webpage <- read_html(url)
  
  # Extract the table
  table <- webpage %>%
    html_node("table.stats_table") %>%
    html_table()
  
  # Set the first row as the header
  colnames(table) <- table[1, ]
  table <- table[-1, ]
  
  # Convert to a tibble with name repair to handle any issues with column names
  table <- as_tibble(table, .name_repair = "unique")
  
  # View the first few rows of the table (optional)
  # print(head(table))
  
  # Save the table to a CSV file with the season in the filename
  filename <- paste0("mancity_shooting_", season, ".csv")
  write.csv(table, filename, row.names = FALSE)
  
  # Print a message indicating success
  print(paste("Saved table for season", season, "to file", filename))
}

# Loop through each URL and scrape the table
for (season in names(urls)) {
  scrape_and_save(urls[[season]], season)
}
