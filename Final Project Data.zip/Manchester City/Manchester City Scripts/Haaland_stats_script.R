# Load required packages
library(rvest)
library(dplyr)

# Define the URL for the Shooting table of Erling Haaland
url <- "https://fbref.com/en/players/1f44ac21/all_comps/Erling-Haaland-Stats---All-Competitions"

# Function to scrape and save the table
scrape_and_save <- function(url, filename) {
  # Read the webpage content
  webpage <- read_html(url)
  
  # Extract the Shooting table
  table <- webpage %>%
    html_node("table#stats_shooting") %>%
    html_table()
  
  # Set the first row as the header
  colnames(table) <- table[1, ]
  table <- table[-1, ]
  
  # Convert to a tibble with name repair to handle any issues with column names
  table <- as_tibble(table, .name_repair = "unique")
  
  # View the first few rows of the table (optional)
  # print(head(table))
  
  # Save the table to a CSV file
  write.csv(table, filename, row.names = FALSE)
  
  # Print a message indicating success
  print(paste("Saved table to file", filename))
}

# Call the function to scrape and save the Shooting table for Erling Haaland
scrape_and_save(url, "haaland_shooting_stats.csv")
