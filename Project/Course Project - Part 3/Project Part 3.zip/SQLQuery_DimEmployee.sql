--Here is the code for the DimCustomer table in the PrimoGoods DM

SELECT 
	ClothingStoreDB.dbo.Employee.E_ID AS Employee_AK, 
	ClothingStoreDB.dbo.Employee.E_Name,
	DATEDIFF(YY, ClothingStoreDB.dbo.Employee.E_DOB, GETDATE()) AS Age,
	CASE 
	WHEN YEAR(ClothingStoreDB.dbo.Employee.E_DOB) BETWEEN 1970 AND 2000 THEN CAST(DATEDIFF(YEAR, ClothingStoreDB.dbo.Employee.E_DOB, GETDATE()) AS VARCHAR) + ' years old'
	END AS EmployeeAge
FROM
	ClothingStoreDB.dbo.Employee