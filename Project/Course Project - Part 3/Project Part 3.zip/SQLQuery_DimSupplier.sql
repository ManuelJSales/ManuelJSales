--Here is the code for the DimStore table in the PrimoGoods DM

SELECT 
    s.Supplier_ID AS Supplier_AK, 
    s.SuppAddress, 
    b.BrandName
FROM 
    ClothingStoreDB.dbo.Supplier s
INNER JOIN 
    ClothingStoreDB.dbo.Brand b ON s.Supplier_ID = b.Supplier_ID
