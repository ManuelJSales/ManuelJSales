SELECT
   ClothingStoreDB.dbo.Store.Store_ID AS StoreID,
    GETDATE() AS Date_SK,
    ClothingStoreDB.dbo.Customer.Cust_ID AS CustomerID,
    ClothingStoreDB.dbo.Employee.E_ID AS EmployeeID,
    NULL AS SupplierID, 
    ClothingStoreDB.dbo.Product.Product_ID AS ProductID,
    ClothingStoreDB.dbo.Customer.Cust_ID AS CustomerID,
    ClothingStoreDB.dbo.Store.Store_ID AS StoreID
FROM 
    ClothingStoreDB.dbo.SalesTransaction
INNER JOIN 
    ClothingStoreDB.dbo.Store ON ClothingStoreDB.dbo.Store.Store_ID = ClothingStoreDB.dbo.Store.Store_ID
INNER JOIN 
    ClothingStoreDB.dbo.Customer ON ClothingStoreDB.dbo.Customer.Cust_ID = ClothingStoreDB.dbo.Customer.Cust_ID
INNER JOIN 
    ClothingStoreDB.dbo.Employee ON ClothingStoreDB.dbo.Employee.E_ID = ClothingStoreDB.dbo.Employee.E_ID
INNER JOIN 
    ClothingStoreDB.dbo.Product ON ClothingStoreDB.dbo.Product.Product_ID = ClothingStoreDB.dbo.Product.Product_ID