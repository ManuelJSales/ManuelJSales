--Here is the code for the DimStore table in the ClothingStore DM

SELECT 
	ClothingStoreDB.dbo.Store.Store_ID AS Store_AK, 
	ClothingStoreDB.dbo.Store.StoreAddress
FROM 
	ClothingStoreDB.dbo.Store
