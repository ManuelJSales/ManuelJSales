--Here is the code for the DimCustomer table in the ClothingStore DM

SELECT 
	ClothingStoreDB.dbo.Customer.Cust_ID AS Customer_AK, 
	ClothingStoreDB.dbo.Customer.Custad
FROM
	ClothingStoreDB.dbo.Customer
