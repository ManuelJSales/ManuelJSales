IF NOT EXISTS(SELECT name FROM master.dbo.sysdatabases			
	WHERE name = N'ClothingStoreDB')
	
	CREATE DATABASE ClothingStoreDB
GO

USE ClothingStoreDB
GO
--
--Drop the tables if exist
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'SalesTransaction')

	DROP TABLE SalesTransaction;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Product')

	DROP TABLE Product;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Brand')

	DROP TABLE Brand;
-- 
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Category')

	DROP TABLE Category;
-- 
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Department')

	DROP TABLE Department;
-- 
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Store')

	DROP TABLE Store;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Employee')

	DROP TABLE Employee;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Customer')

	DROP TABLE Customer;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Supplier')

	DROP TABLE Supplier;
-- 
CREATE TABLE DimDate(
	Date_SK				INT PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10),-- Date in MM-dd-yyyy format
	DayOfMonth			INT, -- Field will hold day number of Month
	DayName				NVARCHAR(9), -- Contains name of the day, Sunday, Monday 
	DayOfWeek			INT,-- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12{}
	MonthName			NVARCHAR(9),-- January, February etc
	MonthOfQuarter		INT,-- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NVARCHAR(9),-- First,Second..
	Year				INT,-- Year value of Date stored in Row
	YearName			CHAR(7), -- CY 2017,CY 2018
	MonthYear			CHAR(10), -- Jan-2018,Feb-2018
	MMYYYY				INT,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsHoliday			BIT,-- Flag 1=National Holiday, 0-No National Holiday
	IsWeekday			BIT,-- 0=Week End ,1=Week Day
	Holiday				NVARCHAR(50),--Name of Holiday in US
	Season				NVARCHAR(10)--Name of Season
);

CREATE TABLE DimStore(
	Store_SK INT NOT NULL,
	Store_BK INT NOT NULL,
	StoreAddress VARCHAR(50)
);

CREATE TABLE DimEmployee(
	Employee_SK INT NOT NULL,
	Employee_BK INT NOT NULL,
	E_DOB DATE,
	E_Name VARCHAR(50)
);

CREATE TABLE DimCustomer(
	Customer_SK INT NOT NULL,
	Customer_BK INT NOT NULL,
	Custad VARCHAR(50)
);

CREATE TABLE DimSupplier(
	Supplier_SK INT NOT NULL,
	Supplier_BK INT NOT NULL,
	SuppAddress VARCHAR(50),
	Brands VARCHAR(50)
);

CREATE TABLE FactTable(
	Store_SK INT NOT NULL,
	Date_SK DATE NOT NULL,
	Customer_SK INT NOT NULL,
	Employee_SK INT NOT NULL,
	Supplier_SK INT NOT NULL,
	ProductID INT,
	CustomerID INT,
	StoreID INT
);